// the configured options and settings for Tutorial
#define slot_machine_VERSION_MAJOR 0
#define slot_machine_VERSION_MINOR 1
